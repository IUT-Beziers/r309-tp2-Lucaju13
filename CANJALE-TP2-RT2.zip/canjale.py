#                    IMPORTS
from tkinter import*
from PIL import Image, ImageTk
import random
#----------------------------------------------------
#                    FENETRES & CANVAS
root = Tk()
root.geometry("750x500")
root.title("Outils des Réseaux")

registered = u"\u00AE"
font1=('Arial',8,'italic')
l1=Label(root,text='CANJALE JUNIOR Lucas'+registered,font=font1) 
l1.pack(side=BOTTOM)

canvas = Canvas(root, bg="grey", width=750, height=500)
canvas.pack()

#--------------------------------------------------
#                    METHODES & FONCTIONS
imageFile = ("r.png")
image1 = ImageTk.PhotoImage(Image.open(imageFile))

imageFile = ("pc.png")
image2 = ImageTk.PhotoImage(Image.open(imageFile))

imageFile = ("sw.png")
image3 = ImageTk.PhotoImage(Image.open(imageFile))

imageFile = ("voip.png")
image4 = ImageTk.PhotoImage(Image.open(imageFile))
#--------------------------------------------------
def client_pc():
   canvas.create_image(random.randint(250, 350),random.randint(70, 400),image=image2, tags='pc')
   canvas.bind("<Button-1>", click)    #click pour effacer
   canvas.bind("<Button-3>", popPC)   #click pour afficher les proprietes
   canvas.bind("<B1-Motion>", move_pc) #click pour deplacer

def client_tel():
   canvas.create_image(random.randint(600, 700),random.randint(50, 400),image=image4, tags='tel')
   canvas.bind("<Button-1>", click) 
   canvas.bind("<Button-3>", popTel)
   canvas.bind("<B1-Motion>", move_tel)

def switch_add():
   canvas.create_image(random.randint(450, 500),random.randint(100, 400),image=image3, tags='Switch')
   canvas.bind("<Button-1>", click)
   canvas.bind("<Button-3>", pop_up)
   canvas.bind("<B1-Motion>", move_sw)

def router_add():
   canvas.create_image(random.randint(50, 100),random.randint(70, 400),image=image1, tags='r')
   canvas.bind("<Button-1>", click)
   canvas.bind("<Button-3>", popR)
   canvas.bind("<B1-Motion>", move_r)

def lignes():
   canvas.create_line(15, 50, 200, 50, width=5, fill="red")

def pop_up(e):
   x,y = e.x, e.y
   changeS.tk_popup(x,y)
   changeS.post(e.x_root, e.y_root)
def popPC(e):
   x,y = e.x, e.y
   changeP.tk_popup(x,y)
   changeP.post(e.x_root, e.y_root)
def popR(e):
   x,y = e.x, e.y
   changeR.tk_popup(x,y)
   changeR.post(e.x_root, e.y_root)
def popTel(e):
   x,y = e.x, e.y
   changeT.tk_popup(x,y)
   changeT.post(e.x_root, e.y_root)

imageF=("swws.png")
img1 = ImageTk.PhotoImage(Image.open(imageF))

imageF=("rrr.png")
img2 = ImageTk.PhotoImage(Image.open(imageF))

imageF=("pccc.png")
img3 = ImageTk.PhotoImage(Image.open(imageF))

imageF=("tel2.png")
img4 = ImageTk.PhotoImage(Image.open(imageF))

def changePC():
   canvas.itemconfig("pc", image=img3)
def changeSW():
   canvas.itemconfig("Switch", image=img1)
def changeTel():
   canvas.itemconfig("tel", image=img4)
def changeRouter():
   canvas.itemconfig("r", image=img3)

# METHODE POUR EFFACER LES IMAGES
def click(e):
   x,y = e.x,e.y
   c = canvas.find_closest(x,y)
   if c:
      canvas.delete(c[0])
#METHODE POUR AFFICHER MENU POP UP
#Petit Menu
changeS = Menu(canvas, tearoff=0)
changeS.add_command(label="Changer Icon", command=lambda: changeSW())

changeP = Menu(canvas, tearoff=0)
changeP.add_command(label="Changer Icon", command=lambda: changePC())

changeR = Menu(canvas, tearoff=0)
changeR.add_command(label="Changer Icon", command=lambda: changeRouter())

changeT = Menu(canvas, tearoff=0)
changeT.add_command(label="Changer Icon", command=lambda: changeTel())

#--------------------------------------------------
#                    DEPLACEMENT 
def left(e):
   x, y = -50, 0
   canvas.move(imageFile, x, y)

def right(e):
   x, y = 50, 0
   canvas.move(imageFile, x, y)

def up(e):
   x,y = 0,-50
   canvas.move(imageFile, x, y)

def down(e):
   x,y = 0, 50
   canvas.move(imageFile, x, y) 
#--------------------------------------------------
def move_pc(e):
   global imageFile
   imageFile = ImageTk.PhotoImage(Image.open('pc.png'))
   canvas.create_image(e.x, e.y, image=imageFile)

def move_tel(e):
   global imageFile2
   imageFile2 = ImageTk.PhotoImage(Image.open('voip.png'))
   canvas.create_image(e.x, e.y, image=imageFile2)

def move_sw(e):
   global imageFile3
   imageFile3 = ImageTk.PhotoImage(Image.open('sw.png'))
   canvas.create_image(e.x, e.y, image=imageFile3)

def move_r(e):
   global imageFile4
   imageFile4 = ImageTk.PhotoImage(Image.open('r.png'))
   canvas.create_image(e.x, e.y, image=imageFile4)
#--------------------------------------------------
#                    MENU & LANCEMENT
sw = Image.open("sw.png")
resized_sw=sw.resize((80,50))
new_sw= ImageTk.PhotoImage(resized_sw)

pc =Image.open("pc.png")
resized_pc=pc.resize((80,50))
new_pc= ImageTk.PhotoImage(resized_pc)

tel = Image.open("voip.png")
resized_tel=tel.resize((80,50))
new_tel= ImageTk.PhotoImage(resized_tel)

r =Image.open("r.png")
resized_r=r.resize((80,50))
new_r= ImageTk.PhotoImage(resized_r)
#---------------------------------------------------
menubar = Menu(root)
switch = Menu(menubar, tearoff=0)
switch.add_command(label="Switch",image=new_sw, command=switch_add)
menubar.add_cascade(label="Switch", menu=switch)

client = Menu(menubar, tearoff=0)
client.add_command(label="PC",image=new_pc, command= client_pc)
client.add_command(label="Telephone",image=new_tel, command=client_tel)
menubar.add_cascade(label="Client", menu=client)

router = Menu(menubar, tearoff=0)
router.add_command(label="Routeur",image=new_r,command=router_add)
menubar.add_cascade(label="Router", menu=router)

lines = Menu(menubar, tearoff=0)
lines.add_command(label="Lignes",command=lignes)
menubar.add_cascade(label="Lignes", menu=lines)

exit = Menu(menubar, tearoff=0)
exit.add_command(label="Sortir",command=root.destroy)
menubar.add_cascade(label="Sortir", menu=exit)
#---------------------------------------------------
#                        Raccourci
root.bind_all("<KeyPress-s>", lambda x: switch_add()) #Raccourci pour les switch's
root.bind_all("<KeyPress-p>", lambda x: client_pc())  #Raccourci pour les pc's
root.bind_all("<KeyPress-r>", lambda x: router_add()) #Raccourci pour les routeurs
root.bind_all("<KeyPress-t>", lambda x: client_tel()) #Raccourci pour les telephones
#----------------------------------------------------
root.config(menu=menubar)
root.mainloop()